#data/generate_sample.py
import csv, os
os.makedirs(os.path.dirname(__file__), exist_ok=True)
path = os.path.join(os.path.dirname(__file__), 'urls_dataset.csv')


#LEGITIMATE URLS

legit = [
    ("https://google.com", 0),
    ("https://github.com", 0),
    ("https://openai.com", 0),
    ("https://example.com", 0),
    ("https://mybank.com/account/home", 0),
    ("https://wikipedia.org/wiki/Main_Page", 0),
    ("https://amazon.com", 0),
    ("https://microsoft.com", 0),
    ("https://apple.com", 0),
    ("https://stackoverflow.com", 0),
    ("https://bbc.com/news", 0),
    ("https://ndtv.com", 0),
    ("https://flipkart.com", 0),
    ("https://instagram.com", 0),
    ("https://linkedin.com", 0),
    ("https://yahoo.com", 0),
    ("https://cloudflare.com", 0),
    ("https://bankofamerica.com", 0),
    ("https://hdfcbank.com", 0),
    ("https://sbi.co.in", 0)
]

#BASIC PHISHING YOU ALREADY PROVIDED

phishing_basic = [
    ("http://verify-paypal.com/login", 1),
    ("http://paypal-account-update.com/secure", 1),
    ("http://secure-login-bank.com/auth", 1),
    ("http://confirm-account-paypal.com", 1),
    ("http://login.paypal.com.example.net", 1),
    ("http://secure-webscr-paypal.org", 1),
    ("http://update-smiles-login.com.br/default", 1),
    ("http://coincoele.com.br/Scripts/smiles/?pt-br/Paginas/default.aspx", 1),
    ("http://smiles.paginas.fakebr.com/login", 1),
    ("http://paypa1-security-update.net", 1),
    ("http://signin-account-validation.com", 1),
    ("http://validate-user-authentication.net", 1),
    ("http://bank-secure-login-check.net", 1),
    ("http://microsoft-reset-password-login.net", 1),
    ("http://amazon-security-check-auth.com", 1),
    ("http://appleid-reset-verify.net", 1),
    ("http://secure-otp-verification-login.com", 1),
    ("http://chaseonline-secure-auth.com", 1),
    ("http://webscr-paypal-security.com", 1),
    ("http://phishingsite-webscr.com", 1)
]


#ADVANCED REAL PHISHING URLS (from your big list)

phishing_advanced = [
("nobell.it/70ffb52d079109d/login.SkyPe.com/cgi-bin/verification", 1),
("www.dghjdgf.com/paypal.co.uk/webscrcmd=_home-customer", 1),
("serviciosbys.com/paypal.cgi.bin.get-into.secure.center/update", 1),
("mail.printakid.com/www.online.americanexpress.com/index.html", 1),
("thewhiskeydregs.com/promocoessmiles/", 1),
("smilesvoegol.servebbs.org/voegol.php", 1),
("premierpaymentprocessing.com/includes/boleto-2via-07.php", 1),
("myxxxcollection.com/v1/js/jih321/bpd.com.do/l.popular.php", 1),
("super1000.info/docs", 1),
("horizonsgallery.com/js/bin/ssl1/www.paypal.com/login.php", 1),
("phlebolog.com.ua/libraries/joomla/results.php", 1),
("docs.google.com/spreadsheet/viewform?formkey=phishdemo", 1),
("www.coincoele.com.br/Scripts/smiles/default.aspx", 1),
("www.henkdeinumboomkwekerij.nl/language/pdf_fonts/smiles.php", 1),
("perfectsolutionofall.net/wp-content/themes/twentyten/wiresource/", 1),
("lingshc.com/old_aol.1.3/Login", 1),
("anonymeidentity.net/remax/remax.htm", 1),
("dutchweb.gtphost.com/zimbra/exch/owa/uleth/index.html", 1),
("www.avedeoiro.com/site/plugins/chase/", 1),
("asladconcentration.com/paplkuk1/webscrcmd=_home", 1),
("www.regaranch.info/grafika/file/2012/www.itau.com.br/", 1),
("optimistic-pessimism.com/aoluserupdatealert.info.htm", 1),
("mercadolivre.com.br.premiosfidelidade2012.com.br/confirmar/", 1),
("www.everythinggoingon.net/~gpeveryt/home/Email/", 1),
("mercadolivre.com.br.premiosfidelidade2012.com.br", 1),
("www.revitolcream.org/secure-code17/security/", 1),
("jameshowardmusic.com/includes/cache/bbnew/bb.php", 1),
("xini.eu/00Qe", 1),
("paypal.com.cgi.bin.webscr.cmd.login.submit.mediareso.com/security", 1),
("ebayisapidlld.altervista.org", 1),
("revitolcream.org/secure-code5/security/login.php", 1),
("sontemeda.altervista.org/paypinoko/procesing.php", 1),
("promusic.co/components/interbank.com/", 1),
("uvb.lg.ua/templates/a216/PayPaI/", 1),
("docs.google.com/a/unmsm.edu.pe/spreadsheet/phish", 1),
("remax.com.behinehsazerooyesh.com/remax/index.htm", 1),
("aclaydance.com/ncpf.php", 1),
("phamxuanlinh.tk/secure-code8/security/login.php", 1),
("stthomasedu.ucoz.ua/microsoft.htm", 1),
("procedimentotamfidelidade.com/atualiza/", 1),
("paypal.com.us.cgi.bin.webscr.cmd.login.submit.bx3digitallp.com", 1),
("tinyurl.com/bswqloj", 1),
("users11.jabry.com/blopp/Aolupdate.htm", 1),
("tad.ly/BUpQLx", 1),
("professionalcrapsplayer.com/logins/Trulia/index.htm", 1),
("westerncentermuseum.org/plugins/tmp/sp.php", 1),
("cardpromocion2012.com.br/vaidevisa/autentica.php", 1),
("portalsalinas.com.br/modules/mod_acepolls/spam.php", 1),
("trigononline.com/Support.php", 1),
("docs.google.com/spreadsheet/viewform?key=phish", 1),
("nextgensmartphones.com/indexer/Trulia/index.htm", 1)
]


#MERGE EVERYTHING

rows = legit + phishing_basic + phishing_advanced


#CSV

with open(path, 'w', newline='', encoding='utf-8') as fh:
    w = csv.writer(fh)
    w.writerow(['url', 'label'])
    w.writerows(rows)

print("Final dataset written to:", path, "Total rows:", len(rows))
